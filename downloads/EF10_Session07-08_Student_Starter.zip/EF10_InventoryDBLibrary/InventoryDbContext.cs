using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryDBLibrary;

public class InventoryDbContext(DbContextOptions<InventoryDbContext> options)
    : DbContext(options)
{
    public DbSet<Item> Items => Set<Item>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();

    // Supplied relationship configuration. Relationship modelling follows the Code First block.
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Item>().HasOne<Category>().WithMany()
            .HasForeignKey(i => i.CategoryId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Item>().HasOne<Supplier>().WithMany()
            .HasForeignKey(i => i.SupplierId).OnDelete(DeleteBehavior.Restrict);
    }
}
