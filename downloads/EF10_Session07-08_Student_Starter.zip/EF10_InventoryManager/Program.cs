using EF10_InventoryDBLibrary;
using EF10_InventoryManager;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Globalization;

CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
Console.WriteLine("DBM Sessions 07–08 - Campus Supply Shop");
DbContextOptions<InventoryDbContext> options;
try
{
    var config = new ConfigurationBuilder().SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json", optional: false).Build();
    var connection = config.GetConnectionString("InventoryDbConnection");
    if (string.IsNullOrWhiteSpace(connection) || connection.Contains("YOUR_SERVER"))
    {
        Console.WriteLine("Set your SQL Server name in appsettings.json first.");
        return;
    }
    if (!string.Equals(new SqlConnectionStringBuilder(connection).InitialCatalog,
        "DBM_Session0708_Shop", StringComparison.OrdinalIgnoreCase))
    {
        Console.WriteLine("Use DBM_Session0708_Shop only.");
        return;
    }
    options = new DbContextOptionsBuilder<InventoryDbContext>().UseSqlServer(connection).Options;
}
catch (Exception ex) when (ex is ArgumentException or IOException or InvalidOperationException or FormatException)
{
    Console.WriteLine($"Configuration error: {ex.Message}");
    return;
}

while (true)
{
    Console.WriteLine("\n1 List items (example) | 2 Search items | 3 Category items");
    Console.WriteLine("4 Supplier summary | 5 Find item | 6 Create item");
    Console.WriteLine("7 Update item | 8 Delete item | 9 Add category | 10 Add supplier");
    Console.WriteLine("11 Update two tracked items | 12 Advanced browser | 13 Category dashboard");
    Console.WriteLine("14 AddRange | 15 UpdateRange | 16 Active status | 17 Disconnected edit");
    Console.WriteLine("18 RemoveRange | 19 Linked report (Join) | 20 Change category | 21 Delete category safely");
    Console.WriteLine("0 Exit");
    Console.Write("Choose: ");
    var choice = Console.ReadLine()?.Trim();
    if (choice is null or "0") break;
    try
    {
        // The disconnected edit owns its own read, save and verification contexts.
        if (choice == "17")
        {
            await WorkshopTasks.DisconnectedEditAsync(options);
            continue;
        }
        using var db = new InventoryDbContext(options);
        switch (choice)
        {
            case "1":
                await Reports.ListAsync(db);
                break;
            case "2":
                if (Inputs.TryName(out var keyword))
                    await QueryTasks.SearchAsync(db, keyword);
                break;
            case "3":
                await Reports.CategoriesAsync(db);
                if (Inputs.TryId("Category ID", out var category))
                    await QueryTasks.CategoryItemsAsync(db, category);
                break;
            case "4":
                await Reports.SuppliersAsync(db);
                if (Inputs.TryId("Supplier ID", out var supplier))
                    await QueryTasks.SupplierSummaryAsync(db, supplier);
                break;
            case "5":
                if (Inputs.TryId("Item ID", out var id))
                    await CrudTasks.ReadAsync(db, id);
                break;
            case "6":
                await Reports.CategoriesAsync(db);
                await Reports.SuppliersAsync(db);
                if (Inputs.TryName(out var name) && Inputs.TryPrice(out var price)
                    && Inputs.TryStock(out var stock) && Inputs.TryId("Category ID", out var catId)
                    && Inputs.TryId("Supplier ID", out var supId))
                {
                    if (!await db.Categories.AnyAsync(c => c.Id == catId)
                        || !await db.Suppliers.AnyAsync(s => s.Id == supId))
                        Console.WriteLine("Category or supplier does not exist.");
                    else
                        await CrudTasks.CreateAsync(db, name, price, stock, catId, supId);
                }
                break;
            case "7":
                if (Inputs.TryPracticeId(out var editId) && Inputs.TryPrice(out var newPrice)
                    && Inputs.TryStock(out var newStock))
                    await CrudTasks.UpdateAsync(db, editId, newPrice, newStock);
                break;
            case "8":
                if (Inputs.TryPracticeId(out var deleteId))
                    await CrudTasks.DeleteAsync(db, deleteId);
                break;
            case "9":
                if (Inputs.TryName(out var categoryName))
                    await CrudTasks.AddCategoryAsync(db, categoryName);
                break;
            case "10":
                if (Inputs.TryName(out var supplierName) && Inputs.TryName(out var city))
                    await CrudTasks.AddSupplierAsync(db, supplierName, city);
                break;
            case "11":
                if (Inputs.TryPracticeId(out var first) && Inputs.TryPracticeId(out var second)
                    && first != second && Inputs.TryStock(out var quantity))
                    await CrudTasks.UpdateTwoAsync(db, first, second, quantity);
                else
                    Console.WriteLine("Use two different practice item IDs and a valid stock value.");
                break;
            case "12":
                await WorkshopTasks.BrowseAsync(db);
                break;
            case "13":
                await WorkshopTasks.DashboardAsync(db);
                break;
            case "14":
                await WorkshopTasks.AddMultipleAsync(db);
                break;
            case "15":
                await WorkshopTasks.UpdateMultipleAsync(db);
                break;
            case "16":
                await WorkshopTasks.SetActiveAsync(db);
                break;
            case "18":
                await WorkshopTasks.RemoveMultipleAsync(db);
                break;
            case "19":
                await WorkshopTasks.LinkedReportAsync(db);
                break;
            case "20":
                await WorkshopTasks.ChangeCategoryAsync(db);
                break;
            case "21":
                await WorkshopTasks.DeleteCategoryAsync(db);
                break;
            default:
                Console.WriteLine("Choose 0 to 21.");
                break;
        }
    }
    catch (DbUpdateException ex)
    {
        Console.WriteLine($"Save failed: {ex.GetBaseException().Message}");
    }
    catch (SqlException ex)
    {
        Console.WriteLine($"SQL Server error {ex.Number}: {ex.Message}");
    }
    catch (InvalidOperationException ex)
    {
        Console.WriteLine($"EF Core error: {ex.Message}");
    }
}
