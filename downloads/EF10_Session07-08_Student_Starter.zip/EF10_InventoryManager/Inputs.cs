using System.Globalization;

namespace EF10_InventoryManager;

// Supplied helpers. Failed input cancels this menu operation.
internal static class Inputs
{
    internal static bool TryId(string label, out int id)
    {
        Console.Write($"{label}: ");
        if (int.TryParse(Console.ReadLine(), out id) && id > 0) return true;
        Console.WriteLine("Enter a positive whole-number ID.");
        return false;
    }

    internal static bool TryPracticeId(out int id)
    {
        if (!TryId("Your created item's ID", out id)) return false;
        if (id > 120) return true;
        Console.WriteLine("IDs 1 to 120 are reserved seed items. Use the ID printed when you created your item.");
        return false;
    }

    internal static bool TryName(out string name)
    {
        Console.Write("Name (1-100 characters): ");
        name = Console.ReadLine()?.Trim() ?? "";
        if (name.Length is > 0 and <= 100) return true;
        Console.WriteLine("Enter a non-empty name up to 100 characters.");
        return false;
    }

    internal static bool TryPrice(out decimal price)
    {
        Console.Write("Price (e.g. 12.50): ");
        if (decimal.TryParse(Console.ReadLine(), NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign,
                CultureInfo.InvariantCulture, out price)
            && price is >= 0 and <= 99999999.99m
            && decimal.Round(price, 2) == price) return true;
        Console.WriteLine("Enter a non-negative price fitting decimal(10,2), with up to two decimal places.");
        return false;
    }

    internal static bool TryStock(out int stock)
    {
        Console.Write("Stock: ");
        if (int.TryParse(Console.ReadLine(), out stock) && stock >= 0) return true;
        Console.WriteLine("Enter a non-negative whole number.");
        return false;
    }
}
