using EF10_InventoryDBLibrary;
using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryManager;

internal static class CrudTasks
{
    internal static async Task ReadAsync(InventoryDbContext db, int id)
    {
        // Worked example (former TODO 04): lookup by primary key.
        var item = await db.Items.FindAsync(id);
        if (item is null) { Console.WriteLine("Item not found."); return; }
        Reports.PrintItems(new[] { item });
    }

    internal static async Task CreateAsync(InventoryDbContext db, string name, decimal price, int stock, int categoryId, int supplierId)
    {
        // Worked example (former TODO 05): the menu validated the foreign keys.
        var item = new Item
        {
            Name = name, UnitPrice = price, Stock = stock, IsActive = true,
            CategoryId = categoryId, SupplierId = supplierId
        };
        db.Items.Add(item);
        await db.SaveChangesAsync();
        Console.WriteLine($"Created item ID: {item.Id}");
    }

    internal static async Task UpdateAsync(InventoryDbContext db, int id, decimal price, int stock)
    {
        // Worked example (former TODO 06): tracked update.
        var item = await db.Items.FindAsync(id);
        if (item is null) { Console.WriteLine("Item not found."); return; }
        item.UnitPrice = price;
        item.Stock = stock;
        await db.SaveChangesAsync();
        Reports.PrintItems(new[] { item });
    }

    internal static async Task DeleteAsync(InventoryDbContext db, int id)
    {
        // Worked example (former TODO 07): a confirmed hard delete.
        var item = await db.Items.FindAsync(id);
        if (item is null) { Console.WriteLine("Item not found."); return; }
        Console.WriteLine($"Delete {item.Name}?");
        Console.Write("Type YES: ");
        if (Console.ReadLine() != "YES") { Console.WriteLine("Cancelled."); return; }
        db.Items.Remove(item);
        await db.SaveChangesAsync();
        Console.WriteLine("Deleted.");
    }

    internal static async Task AddCategoryAsync(InventoryDbContext db, string name)
    {
        // Worked example (former TODO 08): another DbSet.
        var category = new Category { Name = name };
        db.Categories.Add(category);
        await db.SaveChangesAsync();
        Console.WriteLine($"Created category ID: {category.Id}");
    }

    internal static async Task AddSupplierAsync(InventoryDbContext db, string name, string city)
    {
        // Worked example (former TODO 09).
        var supplier = new Supplier { Name = name, City = city };
        db.Suppliers.Add(supplier);
        await db.SaveChangesAsync();
        Console.WriteLine($"Created supplier ID: {supplier.Id}");
    }

    internal static async Task UpdateTwoAsync(InventoryDbContext db, int firstId, int secondId, int stock)
    {
        // Worked example (former TODO 10): two tracked changes, one save.
        var items = await db.Items.Where(i => i.Id == firstId || i.Id == secondId).ToListAsync();
        if (items.Count != 2) { Console.WriteLine("One or both items missing."); return; }
        foreach (var item in items) item.Stock = stock;
        int affected = await db.SaveChangesAsync();
        Console.WriteLine($"State entries written: {affected}");
        Reports.PrintItems(items);
    }
}
