using EF10_InventoryDBLibrary;
using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryManager;

internal static class Reports
{
    internal static async Task ListAsync(InventoryDbContext db)
    {
        var items = await db.Items.AsNoTracking().OrderBy(i => i.Id).ToListAsync();
        PrintItems(items);
    }

    internal static void PrintItems(IEnumerable<Item> items)
    {
        foreach (var i in items)
            Console.WriteLine($"{i.Id,3} | {i.Name,-25} | {i.UnitPrice,8:F2} | Stock {i.Stock,3} | Active {i.IsActive} | Category {i.CategoryId} | Supplier {i.SupplierId}");
    }

    internal static async Task CategoriesAsync(InventoryDbContext db)
    {
        foreach (var c in await db.Categories.AsNoTracking().OrderBy(c => c.Id).ToListAsync())
            Console.WriteLine($"Category {c.Id}: {c.Name}");
    }

    internal static async Task SuppliersAsync(InventoryDbContext db)
    {
        foreach (var s in await db.Suppliers.AsNoTracking().OrderBy(s => s.Id).ToListAsync())
            Console.WriteLine($"Supplier {s.Id}: {s.Name} ({s.City})");
    }
}
