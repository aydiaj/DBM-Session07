using EF10_InventoryDBLibrary;
using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace EF10_InventoryManager;

internal static class WorkshopTasks
{
    internal static async Task BrowseAsync(InventoryDbContext db)
    {
        Console.Write("Keyword (blank = all): ");
        string keyword = Console.ReadLine()?.Trim() ?? "";
        await Reports.CategoriesAsync(db);
        await Reports.SuppliersAsync(db);
        if (!TryFilterId("Category ID (0 = all)", out int categoryId)
            || !TryFilterId("Supplier ID (0 = all)", out int supplierId)
            || !TryMaxPrice(out decimal? maxPrice)
            || !TryYesNo("Available items only? Y/N", out bool availableOnly)
            || !Inputs.TryId("Page number", out int page)
            || page > 10000) return;
        int pageSize = 10;

        // TODO 11 START - Compose filters and return a page.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 11.");
        // TODO 11 END
    }

    internal static async Task DashboardAsync(InventoryDbContext db)
    {
        // TODO 12 START - Group, aggregate and project.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 12.");
        // TODO 12 END
    }

    internal static async Task AddMultipleAsync(InventoryDbContext db)
    {
        await Reports.CategoriesAsync(db);
        await Reports.SuppliersAsync(db);
        if (!Inputs.TryId("Category ID", out int categoryId)
            || !Inputs.TryId("Supplier ID", out int supplierId)) return;
        if (!await db.Categories.AnyAsync(c => c.Id == categoryId)
            || !await db.Suppliers.AnyAsync(s => s.Id == supplierId))
        {
            Console.WriteLine("Invalid category or supplier.");
            return;
        }

        // TODO 13 START - Create two items with valid foreign keys.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 13.");
        // TODO 13 END
    }

    internal static async Task UpdateMultipleAsync(InventoryDbContext db)
    {
        if (!TryTwoPracticeIds(out int first, out int second)
            || !Inputs.TryStock(out int newStock)) return;
        // TODO 14 START - Explicitly update two complete no-tracking objects.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 14.");
        // TODO 14 END
    }

    internal static async Task SetActiveAsync(InventoryDbContext db)
    {
        if (!Inputs.TryPracticeId(out int id)
            || !TryYesNo("Set active? Y/N", out bool isActive)) return;
        // TODO 15 START - Set an existing practice item's active status and save.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 15.");
        // TODO 15 END
    }

    internal static async Task DisconnectedEditAsync(DbContextOptions<InventoryDbContext> options)
    {
        if (!Inputs.TryPracticeId(out int id)) return;
        // TODO 16 START - Display in context A; edit later; save in context B.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 16.");
        // TODO 16 END
    }

    internal static async Task RemoveMultipleAsync(InventoryDbContext db)
    {
        if (!TryTwoPracticeIds(out int first, out int second)) return;
        // TODO 17 START - Retrieve, confirm, remove both and save.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 17.");
        // TODO 17 END
    }

    internal static async Task LinkedReportAsync(InventoryDbContext db)
    {
        // TODO 18 START - Join Items to Categories and Suppliers using their keys.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 18.");
        // TODO 18 END
    }

    internal static async Task ChangeCategoryAsync(InventoryDbContext db)
    {
        await Reports.CategoriesAsync(db);
        if (!Inputs.TryPracticeId(out int id)
            || !Inputs.TryId("New category ID", out int newCategoryId)) return;
        // TODO 19 START - Validate the new category, then change the foreign key.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 19.");
        // TODO 19 END
    }

    internal static async Task DeleteCategoryAsync(InventoryDbContext db)
    {
        await Reports.CategoriesAsync(db);
        if (!Inputs.TryId("Your created category ID", out int id) || id <= 6)
        { Console.WriteLine("Only practice categories may be removed."); return; }
        // TODO 20 START - Check the category exists and that no item references it.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 20.");
        // TODO 20 END
    }

    private static bool TryTwoPracticeIds(out int first, out int second)
    {
        second = 0;
        if (!Inputs.TryPracticeId(out first) || !Inputs.TryPracticeId(out second)) return false;
        if (first == second) { Console.WriteLine("Choose two different items."); return false; }
        return true;
    }

    private static bool TryFilterId(string label, out int id)
    {
        Console.Write($"{label}: ");
        if (int.TryParse(Console.ReadLine(), out id) && id >= 0) return true;
        Console.WriteLine("Enter zero or a positive ID.");
        return false;
    }

    private static bool TryMaxPrice(out decimal? maxPrice)
    {
        Console.Write("Maximum price (blank = unlimited): ");
        string input = Console.ReadLine()?.Trim() ?? "";
        maxPrice = null;
        if (input.Length == 0) return true;
        if (decimal.TryParse(input, NumberStyles.AllowDecimalPoint,
            CultureInfo.InvariantCulture, out decimal price)
            && price is >= 0 and <= 99999999.99m)
        { maxPrice = price; return true; }
        Console.WriteLine("Invalid maximum price.");
        return false;
    }

    private static bool TryYesNo(string label, out bool value)
    {
        Console.Write($"{label}: ");
        var answer = Console.ReadLine()?.Trim().ToUpperInvariant();
        value = answer == "Y";
        if (answer is "Y" or "N") return true;
        Console.WriteLine("Choose Y or N.");
        return false;
    }
}
