using EF10_InventoryDBLibrary;
using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryManager;

internal static class QueryTasks
{
    internal static async Task SearchAsync(InventoryDbContext db, string keyword)
    {
        // TODO 01 START - Active items containing keyword; order by price then ID; print results.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 01.");
        // TODO 01 END
    }

    internal static async Task CategoryItemsAsync(InventoryDbContext db, int categoryId)
    {
        // TODO 02 START - Verify category exists; show its three most expensive active in-stock items.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 02.");
        // TODO 02 END
    }

    internal static async Task SupplierSummaryAsync(InventoryDbContext db, int supplierId)
    {
        // Worked example (former TODO 03): scalar queries.
        if (!await db.Suppliers.AnyAsync(s => s.Id == supplierId))
        {
            Console.WriteLine("Supplier not found.");
            return;
        }
        var query = db.Items.AsNoTracking().Where(i => i.SupplierId == supplierId);
        int count = await query.CountAsync();
        int stock = await query.SumAsync(i => (int?)i.Stock) ?? 0;
        Console.WriteLine($"Item count: {count} | Total stock: {stock}");
    }
}
