using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EF10_InventoryModels;

[Table("Categories", Schema = "dbo")]
public class Category
{
    public int Id { get; set; }
    [Required, StringLength(100)]
    public string Name { get; set; } = "";
}
