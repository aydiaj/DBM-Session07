using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EF10_InventoryModels;

[Table("Suppliers", Schema = "dbo")]
public class Supplier
{
    public int Id { get; set; }
    [Required, StringLength(100)]
    public string Name { get; set; } = "";
    [Required, StringLength(100)]
    public string City { get; set; } = "";
}
